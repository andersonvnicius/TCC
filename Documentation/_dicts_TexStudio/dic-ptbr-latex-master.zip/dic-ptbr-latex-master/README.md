dic-ptbr-latex
==============

Dicionário (.dic) português-Brasil que pode ser utilizado em interpretadores LaTeX.
